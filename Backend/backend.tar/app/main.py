from fastapi import FastAPI
from app.routes import router  # Import routes
from app.auth import router as auth_router
from app.labels import router as labels_router
from app.expenses import router as expenses_router
from app.graphs import router as graphs_router
from fastapi.middleware.cors import CORSMiddleware


app = FastAPI()

# Configure CORS
origins = [
    "http://localhost:3000",   # React dev server
    "http://127.0.0.1:3000",   # Sometimes used too
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routes
app.include_router(auth_router)
app.include_router(labels_router)
app.include_router(expenses_router)
app.include_router(graphs_router)

@app.get("/")
def home():
    return {"message": "Welcome to Carne Asada Griller API"}